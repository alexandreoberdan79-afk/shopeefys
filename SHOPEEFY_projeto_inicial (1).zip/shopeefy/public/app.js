const $ = s => document.querySelector(s);
const money = n => Number(n).toLocaleString("pt-BR",{style:"currency",currency:"BRL"});
let products = [], cart = JSON.parse(localStorage.getItem("shopeefy-cart") || "[]"), activeCategory = "Todos";

async function api(url, options={}) {
  const res = await fetch(url,{headers:{"Content-Type":"application/json"},...options});
  const data = await res.json().catch(()=>({}));
  if(!res.ok) throw new Error(data.error || "Não foi possível concluir a operação.");
  return data;
}
function toast(message){const el=$("#toast");el.textContent=message;el.classList.add("show");setTimeout(()=>el.classList.remove("show"),2400)}
function saveCart(){localStorage.setItem("shopeefy-cart",JSON.stringify(cart));renderCartCount()}
function renderCartCount(){$("#cartCount").textContent=cart.reduce((s,i)=>s+i.qty,0)}
async function loadProducts(){
  const q=$("#searchInput").value.trim();
  products=await api(`/api/products?q=${encodeURIComponent(q)}&category=${encodeURIComponent(activeCategory)}`);
  renderProducts();renderAdmin();
}
function renderProducts(){
  $("#resultCount").textContent=`${products.length} produto(s)`;
  $("#productsGrid").innerHTML=products.length?products.map(p=>`
    <article class="product-card">
      <div class="product-image">${escapeHTML(p.emoji||"📦")}</div>
      <div class="product-info">
        <p class="product-name">${escapeHTML(p.name)}</p>
        ${p.oldPrice?`<div class="old-price">${money(p.oldPrice)}</div>`:""}
        <div class="product-price">${money(p.price)}</div>
        <div class="product-shipping">✓ Opções de entrega disponíveis</div>
        <button class="btn" data-add="${p.id}">Adicionar ao carrinho</button>
      </div>
    </article>`).join(""):`<p class="muted">Nenhum produto encontrado.</p>`;
}
function escapeHTML(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function renderCart(){
  const rows=cart.map(item=>{const p=products.find(x=>x.id===item.id)||item;return `<div class="cart-item"><div><b>${escapeHTML(p.name)}</b><div class="muted">${money(p.price)} cada</div></div><div class="quantity-controls"><button data-qty="${p.id}" data-change="-1">−</button><b>${item.qty}</b><button data-qty="${p.id}" data-change="1">＋</button><button class="remove-btn" data-remove="${p.id}">Remover</button></div></div>`}).join("");
  $("#cartItems").innerHTML=rows||'<p class="muted">Seu carrinho está vazio.</p>';
  const total=cart.reduce((sum,i)=>{const p=products.find(x=>x.id===i.id)||i;return sum+p.price*i.qty},0);
  $("#cartTotal").textContent=money(total);$("#checkoutBtn").disabled=!cart.length;
}
function renderAdmin(){
  $("#adminList").innerHTML=products.map(p=>`<div class="admin-product"><div><b>${escapeHTML(p.name)}</b><small>${escapeHTML(p.category)} · Estoque: ${p.stock??"—"} · ${money(p.price)}</small></div><button class="remove-btn" data-delete="${p.id}">Excluir</button></div>`).join("");
}
function showPanel(id){$("#"+id).classList.remove("hidden");$("#"+id).scrollIntoView({behavior:"smooth",block:"center"})}
document.addEventListener("click",async e=>{
  const add=e.target.closest("[data-add]");if(add){const id=Number(add.dataset.add),p=products.find(x=>x.id===id),found=cart.find(x=>x.id===id);if(found)found.qty++;else cart.push({id,qty:1,...p});saveCart();toast("Produto adicionado ao carrinho!")}
  const qty=e.target.closest("[data-qty]");if(qty){const item=cart.find(x=>x.id===Number(qty.dataset.qty));item.qty+=Number(qty.dataset.change);if(item.qty<=0)cart=cart.filter(x=>x.id!==item.id);saveCart();renderCart()}
  const remove=e.target.closest("[data-remove]");if(remove){cart=cart.filter(x=>x.id!==Number(remove.dataset.remove));saveCart();renderCart()}
  const del=e.target.closest("[data-delete]");if(del){if(confirm("Excluir este produto?")){try{await api(`/api/products/${del.dataset.delete}`,{method:"DELETE"});await loadProducts();toast("Produto excluído.")}catch(err){toast(err.message)}}}
  const cat=e.target.closest("[data-category]");if(cat){e.preventDefault();activeCategory=cat.dataset.category;$("#productHeading").textContent=activeCategory==="Todos"?"Ofertas em destaque":activeCategory;loadProducts()}
  const close=e.target.closest("[data-close]");if(close)$("#"+close.dataset.close).classList.add("hidden");
});
$("#searchForm").addEventListener("submit",e=>{e.preventDefault();loadProducts()});
$("#cartBtn").addEventListener("click",()=>{renderCart();showPanel("cartPanel")});
$("#accountBtn").addEventListener("click",()=>toast("Área de conta: configure autenticação para publicar a loja."));
$("#checkoutBtn").addEventListener("click",()=>showPanel("checkoutPanel"));
$("#productForm").addEventListener("submit",async e=>{
  e.preventDefault();const data=Object.fromEntries(new FormData(e.target));
  data.price=Number(data.price);data.stock=Number(data.stock);
  try{await api("/api/products",{method:"POST",body:JSON.stringify(data)});e.target.reset();await loadProducts();toast("Produto cadastrado!")}
  catch(err){toast(err.message)}
});
$("#checkoutForm").addEventListener("submit",async e=>{
  e.preventDefault();const form=Object.fromEntries(new FormData(e.target));
  const items=cart.map(i=>({productId:i.id,name:i.name,quantity:i.qty,unitPrice:i.price}));
  try{
    const order=await api("/api/orders",{method:"POST",body:JSON.stringify({customer:form.customer,address:form.address,payment:form.payment,shipping:form.shipping,items})});
    $("#orderMessage").textContent=`Pedido ${order.id} registrado! Status: ${order.status}.`;
    cart=[];saveCart();renderCart();e.target.reset();toast("Pedido registrado com sucesso!");
  }catch(err){$("#orderMessage").textContent=err.message}
});
$("#loadOrdersBtn").addEventListener("click",async()=>{
  try{const orders=await api("/api/orders");$("#ordersList").innerHTML=orders.length?orders.map(o=>`<div class="order-row"><b>${escapeHTML(o.id)}</b> — ${escapeHTML(o.customer)} · ${escapeHTML(o.payment)} · ${escapeHTML(o.status)}</div>`).join(""):"Nenhum pedido registrado."}
  catch(err){$("#ordersList").textContent=err.message}
});
(async()=>{try{await loadProducts();renderCartCount()}catch(e){$("#productsGrid").innerHTML='<p>Não foi possível carregar. Inicie o servidor seguindo o README.</p>'}})();
