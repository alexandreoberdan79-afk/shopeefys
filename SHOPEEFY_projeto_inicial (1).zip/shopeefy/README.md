# SHOPEEFY — projeto inicial

Marketplace demonstrativo com catálogo, pesquisa, categorias, carrinho, cadastro/exclusão de produtos e registro de pedidos.

## Como executar no computador

1. Instale o Node.js (versão LTS).
2. Extraia esta pasta.
3. Abra o terminal dentro da pasta `shopeefy`.
4. Execute:

```bash
npm install
npm start
```

5. Acesse `http://localhost:3000`.

Os produtos e pedidos ficam no arquivo `data/store.json`, criado automaticamente.

## O que já funciona

- Catálogo inicial de produtos e busca.
- Filtro por categoria.
- Carrinho com quantidade e total.
- Cadastro e exclusão de produtos no painel.
- Formulário de pedido e seleção de Pix, cartão ou boleto.
- Registro e consulta de pedidos.

## O que falta antes de vender de verdade

Este é um ponto de partida funcional para testes, não uma operação comercial pronta. O pagamento ainda **não é cobrado**: é necessário integrar um provedor (por exemplo, Mercado Pago ou outro gateway), configurar credenciais no servidor e implementar confirmação por webhook. O cálculo/etiqueta de frete dos Correios e transportadoras também precisa de integração com um serviço de logística.

Antes de publicar: implemente login e permissões de administrador, banco de dados de produção, validação de estoque/preços no servidor, proteção contra fraude, HTTPS, política de privacidade, termos de uso, política de troca/devolução e adequação à LGPD. Não use este painel público como administração real sem autenticação.

## Estrutura

- `server.js` — API Node/Express
- `public/index.html` — estrutura da loja
- `public/styles.css` — visual responsivo
- `public/app.js` — interações do site
